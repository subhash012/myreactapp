import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:3001'); // Replace with your server URL

function App() {
  const [text, setText] = useState('');

  useEffect(() => {
    // Handle text updates from the server
    socket.on('update-text', (data) => {
      setText(data);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleTextChange = (e) => {
    const newText = e.target.value;
    setText(newText);
    socket.emit('update-text', newText);
  };

  return (
    <div>
      <textarea value={text} onChange={handleTextChange} />
    </div>
  );
}

export default App;
