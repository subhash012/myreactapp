const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Initialize Passport and session
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

// Sample user data (replace with your actual user data retrieval logic)
const users = [
  { id: 1, username: 'demo', password: '$2b$10$gZpauhugvluJ7Jfr5Tj49OVz6o.j8QBeR9O.bW3Xvc9JziwZu.4My' }, // Password: "password"
];

// Configure Passport to use a Local strategy for authentication
passport.use(
  new LocalStrategy((username, password, done) => {
    // Replace this with your actual user data retrieval logic from a database
    const user = users.find((u) => u.username === username);

    if (!user) {
      return done(null, false, { message: 'Incorrect username' });
    }

    // Compare the entered password with the hashed password stored in the database
    bcrypt.compare(password, user.password, (err, result) => {
      if (err) throw err;
      if (result) {
        return done(null, user);
      } else {
        return done(null, false, { message: 'Incorrect password' });
      }
    });
  })
);

// Serialize and deserialize user
passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  // Replace this with your actual user data retrieval logic from a database
  const user = users.find((u) => u.id === id);
  done(null, user);
});

// Middleware to check if the user is authenticated
const ensureAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/login'); // Redirect to the login page if not authenticated
};

// Set up Express middleware and routes

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" directory
app.use(express.static('public'));

// View engine setup (assuming you are using EJS as the view engine)
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Routes

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/dashboard', ensureAuthenticated, (req, res) => {
  res.render('dashboard', { user: req.user });
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', passport.authenticate('local', { successRedirect: '/dashboard', failureRedirect: '/login-failure' }));

app.get('/login-failure', (req, res) => {
  res.render('login-failure');
});

app.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});

// Example protected route
app.get('/dashboard', ensureAuthenticated, (req, res) => {
  res.send('Dashboard. Only authenticated users can access this.');
});

// Other routes...

// Set up Socket.IO for real-time communication
io.on('connection', (socket) => {
  console.log('A user connected');

  // Handle real-time document editing with Socket.IO
  // ...

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

const PORT = process.env.PORT || 3001;

server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
